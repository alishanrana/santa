import React from "react";
import './Page6.css';
import BL from "./bell.png"

const  Page6 = () => {
    return <div className="firstclass">
<div className="parent-class">
<div className="sec-body2">
<div className="left">
<div className="row2nd"> <div className="bell1"> <img  src={BL}/> </div>   <div className="video1"> 2 Video</div></div>
    <div className="linepara">SANTA CHRISTMAS DAY SURPRISE</div>
    <div className="parafirst">You will receive five custom videos from Santa Claus to a person of your choice</div>
    <div className="para2nd"> . <strong className= "strong3"> Video 1:</strong> On Christmas Day you will receive one personalized video from Santa Claus to a person of your choice. The video will be Christmas and language is aimed towards a younger audience to help boost the magic of Christmas and the spirit of Santa</div>
    <div className="lastdiv1">
    <div className="price1">Price <div className="dollar1">$39</div> </div>
    <div className="chek1"><button>chekout</button> </div>
      </div>
</div>
<div className="centerline"></div>
<div className="right">
   <div className="rowfirst"> <div className="bell2"> <img  src={BL}/> </div>   <div className="video2"> 2 Video</div></div>
    <div className="linefirst">SANTA TITLE HELPER</div>
    <div className="line2nd">You will receive five custom videos from Santa Claus to a person of your choice</div>
    <div className="line3rd"> .<strong className="strong1"> Video 1:</strong> 3 months before Christmas a friendly custom video will be sent to the person of your choice just saying hello from Santa </div>
    <div className="line4th"> .<strong className="strong2"> Video 2:</strong> On Christmas Day you will receive one personalized video from Santa Claus to a person of your choice.
The video will be Christmas and language is aimed towards a younger audience to help boost the magic of Christmas and the spirit of Santa </div>
<div className="lastdiv2">
    <div className="price2">Price  <div className="dollar2">$59</div></div>
    <div className="chek2"> <button>chekout</button>  </div>
      </div>
</div>
</div>
<div className="downline"></div>
</div>


</div>

 
}
export default Page6; 