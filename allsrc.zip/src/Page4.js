import React from "react";
import './Page4.css';
import JS from './jesica.png';
import AN from './anika.png'
import BD from './border.png'
const Page4 = () => {
    return <div className="fullpage">
        <div className="test">TESTIMONIALS</div> <div className="parentdiv1">
            <div className="box1"> <p className="b1" >WHAT THEY'RE SAYING</p>
                <p className="b2">Don't take our word for it.Take theirs....</p></div>
               
            <div className="box2">     <div className="flex2">
                <div className="headd2">  1 VIDEO</div>
              <div className="st2">   <p>  <i class="staric"></i>
                    <i class="staric"></i>
                    <i class="staric"></i>
                    <i class="staric"></i>
                    <i class="staric"></i>  </p></div>
                    </div>
                <div className="jassica">  <div> <img src={JS} /> </div> <div className="name1"> Jessica Brown </div> </div> 
                <div className="paragraph1">With Messages From Santa, we have finally accomplished things that have been waiting forever to get done.</div>
                <div className="whitebox1"></div>
            </div>
                  <div className="box3">  
              <div className="flex1" >   <div className="headd1"> 4 VIDEOS </div> <div className="st1"> <p>
                <i class="stars"></i>
                    <i class="stars"></i>
                    <i class="stars"></i>
                    <i class="stars"></i>
                    <i class="stars"></i> </p> </div> </div>
                    
                  
                <div className="anica">  <div>  <img src={AN} /> </div> <div  className="name2">  Anika Levin </div> </div>
                <div className="paragraph2">hanks Messages from Santa! Your product descriptions are amazing and your service is wonderful . Would definitely recommend and will definitely be ordering again.</div>
                <div className="whitebox2"></div>
                </div>
            </div>
        </div>
    


}
export default Page4;