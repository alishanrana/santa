import React from "react";
import "./santa.css";
import IM from './sanata.png'
// import PN from './snow.png'
import { Icon } from "@iconify/react";
const Santa = () => {
    function onMenuClick() {
        var list = document.getElementById("navigation-bar");
        var new_class_name = "new";
    }

    return <div className="container" >
        <div className="Header">
            <div className="Heading">MESSAGES FROM SANTAS</div>
            <a id="menu-icon" className="menu-icon" onClick={() => onMenuClick()}>
                <Icon style={{ color: "white", marginLeft: "auto", height: "32px", width: "32px", }} icon={"heroicons:bars-3-bottom-right-20-solid"} />
            </a>
            <div className="list" id="navigation-bar">
                <li> <a>How it works</a> </li>
                <li> <a>How it works</a> </li>
                <li> <a>Shop</a> </li>
                <li> <a>ContactUS</a> </li>
            </div>
            <div style={{ color: "white" }} className="icon">Icons</div>
        </div>
        <div className="body1">
            <div className="body2">
                <div className="img">
                    <img src={IM} />
                </div>
                <div className="para">
                    <h1 style={{ color: "white", color: "#FFCB05", }}>Make Christmas Unforgettable</h1>
                    <p style={{ color: "white" }}>Experience holiday magic with Messages from Santa! Get unique video messages from Santa himself, straight from the North Pole. Share your child's holiday wishes and receive Santa's magic in your inbox. Make this Christmas magical!</p>
                    <button className="btn">Gift Messages From Santa</button>
                </div>

            </div>
            {/* <div className="snow ">
                <img src={PN} />
            </div> */}
        </div>
    </div>
}
export default Santa;