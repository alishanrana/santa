import React from "react";
import './Page5.css';
import SS from './smilesanta.png'
import { Icon } from "@iconify/react";
const Page5 = () => {
    return <div className="fullsection">
        <div className="mainheading">Contact Us</div>
        <div className="Mainbody">
            <div className="SantaImage"> <img src={SS} />  </div>
            <div className="section2">
            <div className="phone">
                <div className="touch"> Get in Touch </div>
                <div className="number" >  <a style={{color:"red"}}> <a className="ph-icon"> <Icon   icon={"gg:phone"}/></a> <a className="phonenumber"> +18001231234 </a> </a></div>
            </div>
            <div className="words">We'd love to hear from you! and we love discussing potential projects and new ideas.  Any question of remarks? Just write us a message</div>

            <div className="namef">  <input type="textfield" placeholder="Your Name"></input> </div>
            <div className="parentfield">    <div className="emailf">  <input type="textfield" placeholder="Email Address"></input> </div> 
            <div className="contactf">  <input type="textfield" placeholder="Phone"></input> </div>
             </div>
             <div className="commentf">  <input type="textfield" placeholder="Comment"></input> </div>
             <div className="batan"> <button>Send Messages</button> </div>
            </div>

        </div>


    </div>
}
export default Page5;