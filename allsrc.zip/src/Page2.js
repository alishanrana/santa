import React from "react";
import './pag.css'
// import SG from './giftsanta.png'
// import CH from './child.png'
// import PA from './paper.png'
import FU from './FULLIMAGE.png'
const Page2 = () => {
    return <div className="mainsec">
        {/* <div className="fullbody"> */}
            {/* <div>How it Works</div>

            <div className="div1">
                <div>
                    <img src={SG} />
                </div>
                <div>
                    GIVE SANTA THE ESSENTIAL
                </div>
                <div>After picking your favorite package, we'll ask simple questions to personalize the video for your little one.</div>
                <div> <img src={CH}/> </div>
            </div>
            <div className="div2">
                <div>Choose Your Package</div>
                <div>Select one of our six Christmas Packages, each will soon be sprinkled with the magic of personalization.</div>
                <div> <img src={PA}/> </div>
                <div> SIT BACK AND ENJOY COCO</div>
            </div>

        </div> */}
<img src={FU}/>
    </div>
}
export default Page2;