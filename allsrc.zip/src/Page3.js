import React from "react";
import './Page3.css'
import PI from './picture.png'
import { Icon } from "@iconify/react";
const Page3 = () => {
    return <div className="Mainpackage">
        <div className="top"> OUR PACKAGES</div>
        <div className="mainn2">
            <div className="package1">
                <div className="picture">
                    <img src={PI} />
                </div>
                <div></div>
            </div>
            <div className="package2">
                <div><p>
  <i class="star"></i>
  <i class="star"></i>
  <i class="star"></i>
  <i class="star"></i>
  <i class="star"></i> 234 Reviews
</p></div>
                <div className="north">NORTH POLE CHRONICLE'S</div>
                <div className="para1">Make Christmas Special by sending five video messages to your loved ones!</div>
                <div><hr className="line1"></hr> </div>
                <div className="parts">
                    <div className="haed1">Select Number of Videos:
                   <label>     <button className="oneb">4 Videos</button> </label></div>
                    <div className="haed2">Select Number of Recipient:
                        <button className="twob">2 Recipient</button></div>
                </div>

                <div> <hr className="line2" ></hr> </div>
                <div className="icons">
                  <div>  <Icon  icon={"teenyicons:tick-circle-solid"} style={{color:"green"}} />         Video 1:3 Month Before Christmas </div>
                    <div>  <Icon icon={"teenyicons:tick-circle-solid"} style={{color:"green"}} />         Video 2: 1-2 months before Christmas</div>
                    <div>  <Icon icon={"teenyicons:tick-circle-solid"} style={{color:"green"}} />         Video 3: 2-3 weeks before Christmas</div>
                    <div>  <Icon icon={"teenyicons:tick-circle-solid"} style={{color:"green"}} />          Video 4: Christmas Eve</div>
                    <div> <Icon icon={"teenyicons:tick-circle-solid"} style={{color:"green"}}  />        Video 5: On Christmas Day</div>
                </div>
                <div> <hr className="line3"></hr></div>
                <div className="last"><p>Price</p>
                    <div className="price"> 
                        <p>$119</p></div>
                    <div className="btndiv"> <button className="topbtn" > Check Out</button>  </div>
                </div>
            </div>
        </div>
        <div>
            <button className="buttan">Learn More About Our Packages</button></div>
    </div>
}
export default Page3;