import logo from './logo.svg';
import './App.css';
import Santa from './Santa';
import Santa2 from './Santa2';
import Page2 from './Page2';
import Page3 from './Page3';
import Page4 from './Page4';
import Page5 from './Page5';
function App() {
  return (
    
 
  <div>
    {/* <Santa/> */}
    {/* <Page2/> */}
    {/* <Santa2/> */}
    {/* <Page3/> */}
    <Page5/>
    {/* <Page4/> */}
  </div>
  );
  }

export default App;
