import React from "react";
import './santa2.css';
import GFT from './gift.png'
import MI from './group.png'
import SA from './santtta.png'
const Santa2 = () => {
    return <div className="main1" >
        <div className="headingtop"> CUSTOMIZE YOUR MESSAGES</div>
        <div className="main2">
            <div className="gift">
                <img src={GFT} />
                <div className="ptop">5 VIDEOS FROM SANTA CLAUS</div>
                <div className="pcenter">You will receive five custom videos from Santa Claus to a person of your choice</div>
            </div>
            <div className="Grpimage ">
                <img className="img1" src={MI} />
                <img className="img2" src={SA} />
            </div>


        </div>
        <div className="butn">
            <button>Gift Messages From Santa</button>
        </div>
    </div>
}
export default Santa2;